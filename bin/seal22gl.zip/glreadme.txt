Navy Seals GL version 1.0

##Why##:

The reason why Navy Seals 2.2 couldn't run in 3DFX's openGL drivers,
was that the people who took over the Ns TC, after Goosemann, fucked up
the new models, mp5-sd, barret, m16-raw. So we tested the witch models
that was bugging and killed em. Then we change some of the models and it
worked.

##Changes##:

New Barret Sniper Riefle model
Changes in pickup-weapons
Changes in m16-raw
We are using the mp5 to mp5-sd
Explosive mdl
changes in mp5-sd

##Man behind it##

The Guy who find the reason and made it running in GL is:

Christian Oelund - oelund@post8.inet.tele.dk


##Credits##

Caspar Milan Nielsen - pelsdyret@vip.cybercity.dk

##Further versions##

Not untill we can get the Ns1 source code

